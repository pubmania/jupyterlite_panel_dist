:orphan:

.. index::
   single: examples; {{ filename }}

{{ filename }}
{{ '-' * filename|length }}

.. bokeh-plot:: {{ source_path }}
    :process-docstring:
    :source-position: below
