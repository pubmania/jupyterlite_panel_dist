"""Minimal Panel Hello World Example"""
from panel.pane import HTML

HTML("<h1>Hello Panel World from .py Code File</h1>").servable()
